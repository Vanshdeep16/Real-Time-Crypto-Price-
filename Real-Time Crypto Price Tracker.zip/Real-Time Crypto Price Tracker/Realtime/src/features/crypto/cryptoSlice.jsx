import { createSlice } from '@reduxjs/toolkit';
import sampleData from './sampleData';

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState: sampleData,
  reducers: {
    updatePrices: (state, action) => {
      action.payload.forEach(update => {
        const coin = state.find(c => c.symbol === update.symbol);
        if (coin) Object.assign(coin, update);
      });
    },
  },
});