import React from 'react';
import { useSelector } from 'react-redux';

const formatNumber = (num) => Intl.NumberFormat().format(num);

function CryptoTable() {
  const crypto = useSelector(state => state.crypto);

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>#</th><th>Logo</th><th>Name</th><th>Symbol</th><th>Price</th>
            <th>1h %</th><th>24h %</th><th>7d %</th><th>Market Cap</th>
            <th>24h Volume</th><th>Circulating</th><th>Max</th><th>7D Chart</th>
          </tr>
        </thead>
        <tbody>
          {crypto.map((asset, index) => (
            <tr key={asset.symbol} className="text-center border-t">
              <td>{index + 1}</td>
              <td><img src={asset.logo} alt={asset.symbol} className="w-6 h-6 mx-auto" /></td>
              <td>{asset.name}</td>
              <td>{asset.symbol}</td>
              <td>${asset.price.toLocaleString()}</td>
              <td className={asset.change1h >= 0 ? 'text-green-500' : 'text-red-500'}>{asset.change1h}%</td>
              <td className={asset.change24h >= 0 ? 'text-green-500' : 'text-red-500'}>{asset.change24h}%</td>
              <td className={asset.change7d >= 0 ? 'text-green-500' : 'text-red-500'}>{asset.change7d}%</td>
              <td>${formatNumber(asset.marketCap)}</td>
              <td>${formatNumber(asset.volume24h)}</td>
              <td>{formatNumber(asset.circulatingSupply)}</td>
              <td>{formatNumber(asset.maxSupply)}</td>
              <td><img src={asset.chart} alt="chart" className="w-16 mx-auto" /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CryptoTable;