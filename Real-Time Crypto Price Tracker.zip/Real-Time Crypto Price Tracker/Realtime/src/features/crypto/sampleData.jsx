const sampleData = [
    {
      id: 1,
      name: 'Bitcoin',
      symbol: 'BTC',
      logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
      price: 50000,
      change1h: 0.5,
      change24h: 2.1,
      change7d: -1.2,
      marketCap: 950000000,
      volume24h: 35000000,
      circulatingSupply: 19000000,
      maxSupply: 21000000,
      chart: '/charts/btc.svg'
    },
    {
      id: 2,
      name: 'Ethereum',
      symbol: 'ETH',
      logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png',
      price: 3200,
      change1h: -0.2,
      change24h: 1.5,
      change7d: 3.8,
      marketCap: 380000000,
      volume24h: 22000000,
      circulatingSupply: 117000000,
      maxSupply: null,
      chart: '/charts/eth.svg'
    },
    {
      id: 3,
      name: 'Tether',
      symbol: 'USDT',
      logo: 'https://cryptologos.cc/logos/tether-usdt-logo.png',
      price: 1,
      change1h: 0.0,
      change24h: 0.0,
      change7d: 0.0,
      marketCap: 69000000,
      volume24h: 48000000,
      circulatingSupply: 69000000,
      maxSupply: null,
      chart: '/charts/usdt.svg'
    },
    {
      id: 4,
      name: 'BNB',
      symbol: 'BNB',
      logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png',
      price: 420,
      change1h: 0.3,
      change24h: -1.1,
      change7d: 2.4,
      marketCap: 87000000,
      volume24h: 15000000,
      circulatingSupply: 160000000,
      maxSupply: 200000000,
      chart: '/charts/bnb.svg'
    },
    {
      id: 5,
      name: 'XRP',
      symbol: 'XRP',
      logo: 'https://cryptologos.cc/logos/xrp-xrp-logo.png',
      price: 0.8,
      change1h: 0.1,
      change24h: -0.6,
      change7d: 0.9,
      marketCap: 35000000,
      volume24h: 9000000,
      circulatingSupply: 45000000000,
      maxSupply: 100000000000,
      chart: '/charts/xrp.svg'
    }
  ];
  
  export default sampleData;
  