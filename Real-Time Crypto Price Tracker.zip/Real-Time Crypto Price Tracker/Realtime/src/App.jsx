import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updatePrices } from './features/crypto/cryptoSlice';
import CryptoTable from './features/crypto/CryptoTable';
import './index.css';

function App() {
  const dispatch = useDispatch();
  const cryptoData = useSelector(state => state.crypto);

  useEffect(() => {
    const interval = setInterval(() => {
      const updates = cryptoData.map(asset => ({
        symbol: asset.symbol,
        price: +(asset.price * (1 + (Math.random() - 0.5) / 100)).toFixed(2),
        change1h: +(asset.change1h + (Math.random() - 0.5)).toFixed(2),
        change24h: +(asset.change24h + (Math.random() - 0.5)).toFixed(2),
        volume24h: asset.volume24h + Math.floor(Math.random() * 100000 - 50000)
      }));

      dispatch(updatePrices(updates));
    }, 1500);

    return () => clearInterval(interval);
  }, [cryptoData, dispatch]);

  return (
    <div className="p-4 max-w-full">
      <h1 className="text-2xl font-bold mb-4 text-center">Crypto Tracker</h1>
      <CryptoTable />
    </div>
  );
}

export default App;
